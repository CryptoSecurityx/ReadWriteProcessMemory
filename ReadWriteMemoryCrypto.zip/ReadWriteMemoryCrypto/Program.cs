﻿using System;

namespace ReadWriteMemoryCrypto
{
	class Program
	{
        const UInt64 BASE = 0x0195DEE8;
        const UInt64 OffsetMoney1 = 0x10;
        const UInt64 OffsetMoney2 = 0x0;
        const UInt64 OffsetMoney3 = 0x10;
        const UInt64 OffsetMoney4 = 0x30;

        static void Main(string[] args)
        {
            


            Memory EuroTruck = new Memory("eurotrucks2");
            UInt64 World = EuroTruck.Read<UInt64>(EuroTruck.getBaseAddress() + BASE);
           

            UInt64 SaldoDevedor = EuroTruck.Read<UInt64>(World + OffsetMoney1);
            

            Console.WriteLine(SaldoDevedor.ToString("x8").ToUpper()); ;
            
            Console.ReadLine();

            /*
            Console.WriteLine("Game process Id: " + GTA.getProcessId().ToString("x8").ToUpper());
            Console.WriteLine("Game Module Memory BaseAddress: " + GTA.getBaseAddress().ToString("x8").ToUpper());
            Console.WriteLine(GTA.getFileName());
            UInt64 World = GTA.Read<UInt64>(GTA.getBaseAddress() + WORLD_OFFSET);
            Console.WriteLine("Pointer of World Address [GTA5.exe + 0x2413410] -> 0x" + World.ToString("x8").ToUpper());
            UInt64 PlayerPed = GTA.Read<UInt64>(World + WORLD_PLAYER_OFFSET);
            Console.WriteLine("Pointer of Player Address [World + 0x8] -> 0x" + World.ToString("x8").ToUpper());
            Single Life = GTA.Read<Single>(PlayerPed + PLAYER_HEALTH_OFFSET);
            Console.WriteLine("Current Player Life [PlayerPed + 0x280]: " + Life.ToString());
            while (true) // you use of course a more relieable way then this!
            {
                Life = GTA.Read<Single>(PlayerPed + PLAYER_HEALTH_OFFSET);
                /* Bullet Proof 
                if (Life < 200.0f)
                {
                    Life = 200.0f;
                    GTA.Write<Single>(PlayerPed + PLAYER_HEALTH_OFFSET, Life);
                }
                System.Threading.Thread.Sleep(1);
            }*/

        }
    }
}
